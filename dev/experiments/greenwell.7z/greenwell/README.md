These experiments were written by Connor Greenwell.

These have not been tested and some longer work. Some of the original code
needed to support these experiments has been moved into this directory in it is
needed in the future, but is not under active maintenance.
